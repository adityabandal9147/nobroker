package com.nobroker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NobrokerApplicationTests {

	@Test
	void contextLoads() {
	}

}
